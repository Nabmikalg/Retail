package edu.miu.cs.cs425.retailsupermarket.service;

import edu.miu.cs.cs425.retailsupermarket.domain.Product;

import java.util.List;

public interface ProductService {
    List<Product> getProductDates(Integer id);
    Product addNewProduct(Product product);
    List<Product> getAllProducts();


}
