package edu.miu.cs.cs425.retailsupermarket.controller;

import edu.miu.cs.cs425.retailsupermarket.service.ProductService;
import edu.miu.cs.cs425.retailsupermarket.service.SupplierService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RequiredArgsConstructor
@RestController
@RequestMapping("/retailsupermarket/api/product")
public class ProductController {
    private final ProductService productService;



    @GetMapping("/list")
    public ResponseEntity<?> getAllProduct(){
        return new ResponseEntity<>(productService.getAllProducts(), HttpStatus.OK);

    }
    @GetMapping("/get/{id}")
    public ResponseEntity<?> getProductBySupplierId(@PathVariable Integer  id) {
        try {
            return new ResponseEntity<>(productService.getProductDates(id), HttpStatus.OK);
        } catch (RuntimeException e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }}
