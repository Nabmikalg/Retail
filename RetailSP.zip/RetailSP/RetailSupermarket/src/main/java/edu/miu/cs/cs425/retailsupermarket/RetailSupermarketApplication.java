package edu.miu.cs.cs425.retailsupermarket;

import edu.miu.cs.cs425.retailsupermarket.domain.Product;
import edu.miu.cs.cs425.retailsupermarket.domain.Supplier;
import edu.miu.cs.cs425.retailsupermarket.service.ProductService;
import edu.miu.cs.cs425.retailsupermarket.service.SupplierService;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.aspectj.weaver.ast.Var;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.time.LocalDate;

@RequiredArgsConstructor
@SpringBootApplication
public class RetailSupermarketApplication implements ApplicationRunner {
   private final SupplierService supplierService;
   private final ProductService productSeervice;
    public static void main(String[] args) {
        SpringApplication.run(RetailSupermarketApplication.class, args);
    }
@Transactional
    @Override
    public void run(ApplicationArguments args) throws Exception {

        var supplier1= new Supplier(null,"S1","243-5768",null);
        var supplier2= new Supplier(null,"S2","237-0903",null);
        var supplier3= new Supplier(null,"S3","090-1209",null);

        var saveSp1= supplierService.addNewSupplier(supplier1);
        var saveSp2= supplierService.addNewSupplier(supplier2);
        var saveSp3= supplierService.addNewSupplier(supplier3);


    var product1 = new Product(null, "Santa sweet apples", 1.09, 124, LocalDate.of(2023,5,31), saveSp1);
    var product2 = new Product(null, "Chicken drumsticks ", 2.25, 18, LocalDate.of(2023,4,10), saveSp2);
    var product3 = new Product(null, "Dole Bananas ", 0.55, 1097, LocalDate.of( 2023,5,15), saveSp2);

var saveP1= productSeervice.addNewProduct(product1);
var saveP2= productSeervice.addNewProduct(product2);
var saveP3= productSeervice.addNewProduct(product3);
var saveP4= productSeervice.addNewProduct(product3);
}}



