package edu.miu.cs.cs425.retailsupermarket.repository;

import edu.miu.cs.cs425.retailsupermarket.domain.Supplier;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SupplierRepository extends JpaRepository<Supplier,Integer> {

}
