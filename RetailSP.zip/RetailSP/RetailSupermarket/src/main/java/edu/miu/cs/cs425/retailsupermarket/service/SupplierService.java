package edu.miu.cs.cs425.retailsupermarket.service;

import edu.miu.cs.cs425.retailsupermarket.domain.Supplier;

import java.util.List;

public interface SupplierService {
    Supplier getSupplierById(Integer supplierId);
   Supplier addNewSupplier(Supplier supplier);
    List<Supplier> getAllSupplier();

}
