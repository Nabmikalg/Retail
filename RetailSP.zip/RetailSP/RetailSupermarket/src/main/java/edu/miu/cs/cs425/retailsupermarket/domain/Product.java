package edu.miu.cs.cs425.retailsupermarket.domain;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;
@Entity
@NoArgsConstructor
@AllArgsConstructor
@Setter
@Getter
@Table(name="product")
public class Product {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long ProductId;
    @Column(nullable=false)
    @NotNull(message="product name is required")
    private String name;
    private Double unitPrice;
    private Integer quantityInStock;
    private LocalDate dateSupplied;



    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name="supplier_id",nullable = false)

    private Supplier supplier;
}
