package edu.miu.cs.cs425.retailsupermarket.service.impl;

import edu.miu.cs.cs425.retailsupermarket.domain.Product;
import edu.miu.cs.cs425.retailsupermarket.repository.ProductRepository;
import edu.miu.cs.cs425.retailsupermarket.repository.SupplierRepository;
import edu.miu.cs.cs425.retailsupermarket.service.ProductService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class ProductServiceImpl implements ProductService {

    private final ProductRepository productRepository;
private final SupplierRepository supplierRepository;


    @Override
    public Product addNewProduct(Product product) {
        return productRepository.save(product);
    }

    @Override
    public List<Product> getAllProducts() {
        return productRepository.findAll();
    }


    @Override
    public List<Product> getProductDates(Integer id) {
        return productRepository.getProductsBySupplierId(id);
    }}
