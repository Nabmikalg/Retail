package edu.miu.cs.cs425.retailsupermarket.controller;

import edu.miu.cs.cs425.retailsupermarket.service.SupplierService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
@RequiredArgsConstructor
@RestController
@RequestMapping("/retailsupermarket/api/supplier")
public class SupplierController {
    private final SupplierService supplierService;



    @GetMapping("/list")
    public ResponseEntity<?> getAllSupplier(){
        return new ResponseEntity<>(supplierService.getAllSupplier(), HttpStatus.OK);

    }
    @GetMapping("/get/{id}")
    public ResponseEntity<?> getSupplierById(@PathVariable Integer  id) {
        try {
            return new ResponseEntity<>(supplierService.getSupplierById(id), HttpStatus.OK);
        } catch (RuntimeException e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }}