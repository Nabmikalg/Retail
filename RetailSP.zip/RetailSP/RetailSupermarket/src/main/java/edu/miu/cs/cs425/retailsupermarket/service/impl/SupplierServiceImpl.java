package edu.miu.cs.cs425.retailsupermarket.service.impl;

import edu.miu.cs.cs425.retailsupermarket.domain.Supplier;
import edu.miu.cs.cs425.retailsupermarket.repository.ProductRepository;
import edu.miu.cs.cs425.retailsupermarket.repository.SupplierRepository;
import edu.miu.cs.cs425.retailsupermarket.service.SupplierService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
@RequiredArgsConstructor
public class SupplierServiceImpl implements SupplierService {

    private final SupplierRepository supplierRepository;

    @Override
    public Supplier getSupplierById(Integer supplierId) {
       return supplierRepository.findById(supplierId).orElseThrow(()-> new RuntimeException("Not found"));

    }

    @Override
    public Supplier addNewSupplier(Supplier supplier) {
        return supplierRepository.save(supplier);
    }

    @Override
    public List<Supplier> getAllSupplier() {
        return supplierRepository.findAll();
    }

    }

