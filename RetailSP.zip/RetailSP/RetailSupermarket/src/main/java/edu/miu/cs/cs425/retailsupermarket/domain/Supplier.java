package edu.miu.cs.cs425.retailsupermarket.domain;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Entity
@NoArgsConstructor
@AllArgsConstructor
@Setter
@Getter
@Table(name="supplier")

public class Supplier {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer supplierId;
    @Column(nullable=false)
    @NotNull(message="Supplier name is required")
    private String supplierName;
    private String contactPhone;

    @OneToMany(mappedBy = "supplier",cascade = CascadeType.ALL)
    private List<Product> products;

}
